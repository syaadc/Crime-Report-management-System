package com;
import java.io.*;
import java.util.Random;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import javax.swing.JOptionPane;
 
public class SendMail extends HttpServlet {
    
   public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException 
   {
     
       Random rand = new Random();
       int randint = rand.nextInt(100000);
       String str=Integer.toString(randint);
      String to = "sachin1995yadav@gmail.com";
 
      
      String from = "99zakariya@gmail.com";
 
      // Assuming you are sending email from localhost
      String host = "localhost";
 
     
      Properties properties = System.getProperties();
 
      
      properties.setProperty("smtp.gmail.com", host);
 
     
      Session session = Session.getDefaultInstance(properties);
      
      
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();

      try {
         
         // Create a default MimeMessage object.
         MimeMessage message = new MimeMessage(session);
         
         // Set From: header field of the header.
         message.setFrom(new InternetAddress(from));
         
         // Set To: header field of the header.
         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
         // Set Subject: header field
         message.setSubject("OTP");

         // Send the actual HTML message, as big as you like
         message.setContent(str, "text/html" );
         
         // Send message
         Transport.send(message);
         out.print("OTP send");
     
      } catch (MessagingException mex) {
          JOptionPane.showMessageDialog(null, "Exception="+mex);
      }
   }
   
} 